
#include "Book.h"
#include <vector>

double getBookTotal(const vector<Book*> &books) {
	double total = 0;
	for (size_t i = 0; i < books.size(); i++) {
		total += books.at(i)->getPrice();
	}
	return total;
}

int main() {
	vector<Book*> knjige;
	

	Book info("Naslov", "jaz", 10, 10);
	Book info1 = Book(info);
	Book info2 = Book();
	Book* info3 = new Book(info);
	Book* info4 = new Book("Naslov1", "JAZ1", 20,10);
	knjige.push_back(info3);
	knjige.push_back(info4);
	knjige.push_back(&info1);

	info.print();
	info2.print();
	info3->print();

	cout << info.getPages() << endl;

	cout << info4->toString() << endl;
	Book avtor;
	avtor.addAuthor(new Author("aleks", "bedenik", "M"));
	cout << avtor.getAuthorNames() << endl;
	

	cout <<"Cena skupaj" << getBookTotal(knjige);
	Book::createDemoBook().print();
	delete info3;
	delete info4;
	system("PAUSE");
	return 0;
}
//https://www.tutorialspoint.com/What-is-the-difference-between-class-variables-and-instance-variables-in-Java
//https://softwareengineering.stackexchange.com/questions/293478/what-are-the-differences-between-class-variables-and-instance-variables-in-java