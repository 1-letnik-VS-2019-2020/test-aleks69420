#include "Date.h"
Date::Date(int day, int month, int year) : day(day), month(month), year(year) {

}

std::string Date::toString() const {
	return "Dan" + std::to_string(day) + "Mesec: " + std::to_string(month) + "Leto: " + std::to_string(year);
}

int Date::getDay() const {
	return this->day;
}
int Date::getMonth() const {
	return this->month;
}
int Date::getYear() const {
	return this->year;
}

bool Date::isEqual(const Date& drugo) const {
	std::string ena = std::to_string(this->year) + "-" + std::to_string(this->month) + "-" + std::to_string(this->day);
	std::string dva = std::to_string(drugo.year) + "-" + std::to_string(drugo.month) + "-" + std::to_string(drugo.day);

	if (ena == dva) {
		return true;
	}
	else {
		return false;
	}
}

bool Date::isAfter(const Date& drugo) const {
	std::string ena = std::to_string(this->year) + "-" + std::to_string(this->month) + "-" + std::to_string(this->day);
	std::string dva = std::to_string(drugo.year) + "-" + std::to_string(drugo.month) + "-" + std::to_string(drugo.day);

	if (ena > dva) {
		return true;
	}
	else {
		return false;
	}
}

bool Date::isBefore(const Date& drugo) const {
	std::string ena = std::to_string(this->year) + "-" + std::to_string(this->month) + "-" + std::to_string(this->day);
	std::string dva = std::to_string(drugo.year) + "-" + std::to_string(drugo.month) + "-" + std::to_string(drugo.day);

	if (ena < dva) {
		return true;
	}
	else {
		return false;
	}
}