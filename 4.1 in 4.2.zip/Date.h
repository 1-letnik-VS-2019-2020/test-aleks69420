#pragma once
#include <string>
class Date
{
private:
	int day, month, year;
public:
	Date(int day, int month, int year);
	std::string toString() const;

	int getDay() const;
	int getMonth() const;
	int getYear() const;

	bool isEqual(const Date& second) const;
	bool isAfter(const Date& second) const;
	bool isBefore(const Date& second) const;

};

