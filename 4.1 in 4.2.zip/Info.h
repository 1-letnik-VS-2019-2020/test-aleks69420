#pragma once
#include <string>
class Info
{
private:
	std::string kategorija;
	int  rating;
public:

	void setKategorija(std::string kategorija);
	void setRating(int rating);
	
	Info(std::string kategorija, int rating);
	std::string toString() const;
	std::string getKategorija() const;
	int getRating() const;
	
};

