#include "Info.h"
Info::Info(std::string kategorija, int rating) : kategorija(kategorija), rating(rating) {

}

void Info::setKategorija(std::string kategorija) {
	this->kategorija = kategorija;
}

void Info::setRating(int rating) {
	this->rating = rating;
}


std::string Info::getKategorija() const {
	return this->kategorija;
}
int Info::getRating() const {
	return this->rating;
}

std::string Info::toString() const {
	return "Kategorija" + kategorija + "rating" + std::to_string(rating);
}