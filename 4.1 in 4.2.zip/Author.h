#pragma once
#include <string>

class Author {
private:
	std::string name, email;
	char gender;
public:

	void setName(std::string name);
	void setEmail(std::string email);
	void setGender(char gender);
	Author( std::string name , std::string email, char gender);
	std::string toString() const;
	std::string getEmail() const;
	std::string getName() const;
	char getGender() const;
};