#include "Book.h"
#include <random>
int Book::idCounter = 10000;

Book::Book() : title(""), publisher(""), pages(0), price(0) , id(idCounter), authors(0) {
	idCounter++;
}


Book::Book(const Book& t) : title(t.title), publisher(t.publisher), pages(t.pages),price(t.price),id(idCounter) {
	idCounter++;
}


Book::Book(string title, string publisher, int pages, double price) : title(title), publisher(publisher), pages(pages), price(price), id(idCounter) {
	idCounter++;
}

Book::~Book() {

}

void Book::setTitle(string title) {
	this->title = title;
}
void Book::setPublisher(string publisher)  {
	this->publisher = publisher;
}
void Book::setPages(int pages) {
	this->pages = pages;
}
void Book::setPrice(double price) {
	this->price = price;
}
string Book::getTitle() const{
	return title;
}
string Book::getPublisher() const{
	return publisher;
}
int Book::getPages() const{
	return pages;
}
double Book::getPrice() const{
	return price;
}
int Book::getId() const{
	return id;
}
//int Book :: getidCounter() {
//	return idCounter;
//}

void Book::print() const {
	cout << "Title : " << title << " Publisher : " << publisher << " Pages : " << pages << " Price : " << price << " ID:" << id <<   endl;
}
string Book::toString() const{

	string txt = "Title : " + title + " Publisher : " + publisher + " Pages : " + to_string(pages) + " Price : " + to_string(price);
	txt += "Name: ";
	for (size_t i = 0; i < authors.size(); i++) {
		txt += authors.at(i)->getName() + " ";
	}
	return txt;
}
string random() {              //rand metoda
	string s("ALEKSDKJBNAFSKN");
	random_device rd;
	mt19937 generator(rd());
	shuffle(s.begin(), s.end(), generator);
	return s.substr(0, 15);
}
Book Book::createDemoBook() {                                                   //kreiramo demo book
	Book nBook = Book(random(), random(), rand() % 100 + 1, rand() % 50 + 1);
	return nBook;
}

string Book::getAuthorNames() const {
	string name;
	for (size_t i = 0; i < authors.size(); i++) {
		name += authors[i]->getName() + " I " ;
	}
	return name;
}

void Book::setInfo(Info* info) {
	this->info = info;
}

vector<Book*> Book::getBooksBetween(vector<Book*> books, const Date& from, const Date& to) const {
	vector<Book*> rez;

	for (size_t i = 0; i < books.size(); i++) {
		if (books.at(i)->getPublished()->isEqual(from) || books.at(i)->getPublished()->isEqual(to)) {
			rez.push_back(books.at(i));
		}
		else if (books.at(i)->getPublished()->isAfter(from) && books.at(i)->getPublished()->isBefore(to)) {
			rez.push_back(books.at(i));
		}

	}
	return rez;
}