#include <string>
#include <iostream>
#include <vector>
#include "Author.h"
#include "Info.h"
#include "Date.h"
using namespace std;

class Book {
private:
	string title;
	string publisher;
	int pages;
	double price;
	static int idCounter;
	int id;
	vector<Author*> authors;
	Info* info;
public:
	void setTitle(string title);
	void setPrice(double price);
	void setPublisher(string title);
	void setPages(int pages);
	void SetPublisher(Date* published);
	Book();
	Book(const Book& t);
	Book(string title1, string publisher1, int pages1,double price1);
	~Book();

	string getTitle() const;
	string getPublisher() const;
	int getPages() const;
	int getId() const;
	double getPrice() const;

	//int getidCounter();
	void print() const;
	string toString() const;
	static Book createDemoBook();
	void addAuthor(Author* author);
	string getAuthorNames() const;
	void setInfo(Info* info);

	Date* getPublished() const;
	vector<Book*> getBooksBetween(vector<Book*> books, const Date& from, const Date& to) const;
	
};
