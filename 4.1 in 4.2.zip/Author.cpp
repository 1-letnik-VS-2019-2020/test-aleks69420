#include "Author.h"

Author::Author(std::string name, std::string email, char gender) : name(name), email(email), gender(gender) {

}

void Author::setName(std::string name) {
	this->name = name;
}

void Author::setEmail(std::string email) {
	this->email = email;
}

void Author::setGender(char gender) {
	this->gender = gender;
}
std::string Author::getName() const {
	return this->name;
}
std::string Author::getEmail() const {
	return this->email;
}
char Author::getGender() const {
	return this->gender;
}
std::string Author::toString() const {
	return "name: " + name + "Email: " + email + "gender: " + gender;
}